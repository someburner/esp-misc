# Crypto
--------

## Introduction





## Public Key Crypto

* [Wiki](https://en.wikipedia.org/wiki/Public-key_cryptography)
* [sodium](https://download.libsodium.org/doc/public-key_cryptography/authenticated_encryption.html)
* [libsodium github](https://github.com/jedisct1/libsodium-doc/blob/master/public-key_cryptography/authenticated_encryption.md)

## Helpful Tools

* [pysodium](https://github.com/stef/pysodium)


Snippit from [RFC7905](https://tools.ietf.org/html/rfc7905):

ChaCha is a stream cipher developed by D. J. Bernstein in 2008. It is a
refinement of Salsa20, which is one of the selected ciphers in the eSTREAM
portfolio, and it was used as the core of the SHA-3 finalist, BLAKE.

The variant of ChaCha used in this document has 20 rounds, a 96-bit nonce, and
a 256-bit key; it is referred to as "ChaCha20". This is the conservative variant
(with respect to security) of the ChaCha family and is described in
[RFC7539](https://tools.ietf.org/html/rfc7539).

Poly1305 is a Wegman-Carter, one-time authenticator designed by D. J. Bernstein.
Poly1305 takes a 256-bit, one-time key and a message, and it produces a 16-byte
tag that authenticates the message such that an attacker has a negligible chance
of producing a valid tag for an inauthentic message. It is described in
[RFC7539](https://tools.ietf.org/html/rfc7539).

* **ChaCha20**: stream cipher
* **Poly1305**: authenticator
* **chachapoly**: ChaCha20 stream cipher + Poly1305 authentication
* **Curve25519/Ed25519**: Public key algorithms

## Glossary

* **AEAD**: Authenticated Encryption with Associated Data
* **ECDH**: Elliptic curve Diffie–Hellman - an anonymous key agreement protocol
  that allows two parties, each having an elliptic curve public–private key
  pair, to establish a shared secret over an insecure channel.
* ****:
* ****:
* ****:
* ****:


## Learning Resources

* [Basics of ECDH](http://andrea.corbellini.name/2015/05/30/elliptic-curve-cryptography-ecdh-and-ecdsa/)







# end
