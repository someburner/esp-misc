#ifndef _CRYPTO_TEST_H_
#define _CRYPTO_TEST_H_

#include <stdint.h>

typedef uint8_t u8;
typedef int32_t s32;
typedef int64_t limb;

void doit(u8 *ek,const u8 *e,const u8 *k);

void fill_random(u8* buf);
void crypto_test_init();

// void test_curve25519();

#endif /* end crypto_test.h */
