#include "user_interface.h"
#include "user_config.h"

#include "../include/rom.h"
#include "../libc/c_stdio.h"
#include "../platform/platform.h"
#include "../libc/c_ctype.h"

#include "curve25519_donna.h"
#include "crypto_test.h"


static os_timer_t crypto_test_timer;
static int test_state = 0;
static uint32_t start;

void doit(u8 *ek,const u8 *e,const u8 *k)
{
   int i;
   u8 s;

   uint32_t tmpStart = system_get_time()/1000UL;

   while (s = curve25519_donna_debug(ek,e,k))
   {
      uint32_t now = system_get_time()/1000UL;
      CRYPTO_DBG("%hd took %lu ms\n", s, (now-tmpStart));
      tmpStart = now;
   }
   for (i = 0; i < 32; ++i)
      CRYPTO_DBG("%hx", e[i]);
   CRYPTO_DBG(" ");

   for (i = 0; i < 32; ++i)
      CRYPTO_DBG("%hx", k[i]);
   CRYPTO_DBG(" ");

   for (i = 0; i < 32; ++i)
      CRYPTO_DBG("%hx", ek[i]);
   CRYPTO_DBG("\n");
}

static u8 e1k[32];
static u8 e2k[32];
static u8 e1e2k[32];
static u8 e2e1k[32];
// static u8 e1[32] = {3};
// static u8 e2[32] = {5};

static u8 e1[32];
static u8 e2[32];
static u8 k[32] = {9};

static int cnt = 0;
static int err = 0;


void fill_random(u8* buf)
{
   int i;

   for (i=0; i<8; i++)
   {
      uint32_t r = my_trng();
      buf[4*i] = (u8) (r >> 24);
      buf[4*i+1] = (u8) (r >> 16);
      buf[4*i+2] = (u8) (r >> 8);
      buf[4*i+2] = (u8)r;
   }
}


static void crypto_test_timer_cb(void * arg)
{
   os_timer_disarm(&crypto_test_timer);

   uint32_t next_delay = 1;
   int i;

   if (err)
   {
      CRYPTO_DBG("error?\n");
   }

   switch (test_state++)
   {
      case 0:
      {
         fill_random(e1);
         CRYPTO_DBG("e1: ");
         for (i = 0; i < 32; i++)
            CRYPTO_DBG("%x", e1[i]);
         CRYPTO_DBG("\n");
      } break;

      case 1:
      {
         fill_random(e2);
         CRYPTO_DBG("e2: ");
         for (i = 0; i < 32; i++)
            CRYPTO_DBG("%x", e2[i]);
         CRYPTO_DBG("\n");
      } break;

      case 2:
      {
         start = system_get_time()/1000UL;
         doit(e1k,e1,k);
      } break;

      case 3:
      {
         doit(e2e1k,e2,e1k);
      } break;

      case 4:
      {
         doit(e2k,e2,k);
      } break;

      case 5:
      {
         doit(e1e2k,e1,e2k);
      } break;

      case 6:
      {
         for (i = 0; i < 32; ++i)
         {
            if (e1e2k[i] != e2e1k[i])
            {
               CRYPTO_DBG("FAILURE at pass %d\n", cnt);
               err=1;
            }
            else
            {
               ++cnt;
               for (i = 0; i < 32; ++i)
                  e1[i] ^= e2k[i];

               for (i = 0; i < 32; ++i)
                  e2[i] ^= e1k[i];

               for (i = 0; i < 32; ++i)
                  k[i] ^= e1e2k[i];

               uint32_t now = system_get_time()/1000UL;
               CRYPTO_DBG("Pass %d SUCCESS in %lu ms\n", cnt, (now-start));
            }
         }
      } break;

      default:
      {
         test_state = 0;
         os_timer_disarm(&crypto_test_timer);
         return;
      } break;
   }
   CRYPTO_DBG("test_state = %d\n", test_state);

   os_timer_arm(&crypto_test_timer, next_delay, false);
}

void crypto_test_init()
{
   test_state = 0;

   os_timer_disarm(&crypto_test_timer);
   os_timer_setfn(&crypto_test_timer, (os_timer_func_t *)crypto_test_timer_cb, NULL);
   os_timer_arm(&crypto_test_timer, 7000, false);

   CRYPTO_DBG("Crypto test Init\n");

}


#if 0
void test_curve25519()
{
   int i;

   // Start time in ms
   uint32_t tmpStart = system_get_time()/1000UL;

   if (!err)
   {
      doit(e1k,e1,k);
      os_delay_us(1000);
      doit(e2e1k,e2,e1k);
      os_delay_us(1000);
      doit(e2k,e2,k);
      os_delay_us(1000);
      doit(e1e2k,e1,e2k);
      os_delay_us(1000);

      for (i = 0; i < 32; ++i)
      {
         if (e1e2k[i] != e2e1k[i])
         {
            CRYPTO_DBG("FAILURE at pass %d\n", cnt);
            err=1;
         }
         else
         {
            ++cnt;
            for (i = 0; i < 32; ++i)
               e1[i] ^= e2k[i];

            for (i = 0; i < 32; ++i)
               e2[i] ^= e1k[i];

            for (i = 0; i < 32; ++i)
               k[i] ^= e1e2k[i];

            uint32_t now = system_get_time()/1000UL;
            CRYPTO_DBG("Pass %d SUCCESS in %lu ms\n", cnt, (now-tmpStart));
         }
      }
   }
}
#endif
