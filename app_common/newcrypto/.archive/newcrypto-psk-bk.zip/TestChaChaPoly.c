/*
 * Copyright (C) 2015 Southern Storm Software, Pty Ltd.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

/*
This example runs tests on the ChaChaPoly implementation to verify
correct behaviour.
*/
#include "user_interface.h"
#include "user_config.h"
#include "../libc/c_stdio.h"

#include "box.h"
#include "Crypto.h"
#include "ChaChaPoly.h"
#include "TestChaChaPoly.h"

#define MSG_SIZE              21

uint8_t key[CRYPTO_BOX_KEY_SIZE];
uint8_t nonce[CRYPTO_BOX_XNONCE_SIZE + CRYPTO_BOX_NONCE_SIZE];
uint8_t subkey[CRYPTO_BOX_KEY_SIZE];
uint8_t plaintext[MSG_SIZE];
uint8_t ciphertext[MSG_SIZE + CRYPTO_BOX_AUTH_SIZE];

static uint8_t const alice_pk[] = {
   0x9c, 0x8c, 0x96, 0x59, 0xd4, 0xae, 0xe4, 0xe3,
   0x49, 0x8f, 0x1b, 0xc8, 0x1d, 0x1f, 0x39, 0x81,
   0xb3, 0x34, 0x01, 0x5e, 0x0e, 0x5e, 0x10, 0x0d,
   0x2e, 0x3e, 0x0a, 0x15, 0x36, 0x9a, 0x60, 0x2f
};

static uint8_t const bob_pk[] = {
   0xf6, 0xc0, 0x0d, 0x84, 0x6e, 0xc8, 0x4b, 0x87,
   0xde, 0xfa, 0xa5, 0xf8, 0x33, 0x39, 0x34, 0x79,
   0xfe, 0x10, 0x1a, 0xcd, 0x6e, 0x03, 0x7c, 0x59,
   0x1e, 0x55, 0x89, 0x8f, 0x18, 0xe1, 0xca, 0x4e
};

static uint8_t const bob_secret[] = {
   0xe7, 0x42, 0x3a, 0xdf, 0xdb, 0x5c, 0x30, 0x8f,
   0x89, 0x0c, 0xfa, 0xa6, 0x44, 0x93, 0xfd, 0x74,
   0xdb, 0x01, 0x75, 0x0b, 0x8b, 0x96, 0x38, 0xd5,
   0xa0, 0x95, 0x89, 0x0a, 0x24, 0x70, 0x91, 0x25
};

static uint8_t const testNonce[] = {
   0xcd, 0x7c, 0xf6, 0x7b, 0xe3, 0x9c, 0x79, 0x4a
};


// static uint8_t const testNonce[] = {
//    0x36, 0x69, 0xff, 0x27, 0x10, 0xc3, 0xb1, 0x03,
//    0xcf, 0x18, 0x26, 0x56, 0xea, 0xc7, 0x45, 0x36,
//    0xea, 0x6d, 0xf4, 0xf7, 0x6e, 0xd3, 0x65, 0xb0
// };

// static uint8_t const testKey[] = {
//    0x42, 0x90, 0xbc, 0xb1, 0x54, 0x17, 0x35, 0x31,
//    0xf3, 0x14, 0xaf, 0x57, 0xf3, 0xbe, 0x3b, 0x50,
//    0x06, 0xda, 0x37, 0x1e, 0xce, 0x27, 0x2a, 0xfa,
//    0x1b, 0x5d, 0xbd, 0xd1, 0x10, 0x0a, 0x10, 0x07
// };


static char* testMsg = { "All dogs go to heave" };

static uint8_t buffer[MAX_PLAINTEXT_LEN];


static void testPrintBuf()
{
#ifdef CRYPTO_DEBUG
   int i;
   CRYPTO_DBG("testPrintBuf Decrypted:\n");
   for (i=0; i<21; i++)
      CRYPTO_DBG("%c", buffer[i]);

   CRYPTO_DBG("\n");
#endif
}

bool testDecrypt(uint8_t * input, uint16_t datalen)
{
   bool ok = false;

   CRYPTO_DBG("testDecrypt %u bytes..\n", datalen);

   uint8_t r;
/*
   crypto_box_open(
      uint8_t *m, // ciphertext + CRYPTO_BOX_AUTH_SIZE,  --> message
      size_t len, // MSG_SIZE
      const uint8_t *a, // ciphertext,  --> authenticator buffer
      const uint8_t *k, // subkey ?
      const uint8_t *n) // nonce + CRYPTO_BOX_XNONCE_SIZE
*/
   // r = crypto_box_open(input + CRYPTO_BOX_AUTH_SIZE, /* message */
   //                     datalen, // MSG_SIZE,
   //                     input, /* authenticator buffer */
   //                     subkey,
   //                     testNonce + CRYPTO_BOX_XNONCE_SIZE);
   r = crypto_box_open(input + CRYPTO_BOX_AUTH_SIZE, /* message */
                       datalen, // MSG_SIZE,
                       input, /* authenticator buffer */
                       subkey,
                       testNonce + CRYPTO_BOX_XNONCE_SIZE);

   // if (ok)
   // {

   memcpy(buffer, input, 21);
   CRYPTO_DBG("Passed\n");
   testPrintBuf();
   return true;
   // }
   // CRYPTO_DBG("Failed\n");
   // return false;
}

void TestChaChaPoly_init()
{
   CRYPTO_DBG("TestChaChaPoly_init\n");

   /* Assume key, nonce and plaintext are initialized... */

   /* Derive a Salsa20 subkey */
   // void crypto_xsalsa20_subkey(uint8_t *s, const uint8_t *k, const uint8_t *n)
   // memcpy(subkey, alice_pk, CRYPTO_BOX_KEY_SIZE);
   // crypto_xsalsa20_subkey(subkey, bob_secret, testNonce);

   memcpy(subkey, bob_secret, CRYPTO_BOX_KEY_SIZE);
   crypto_xsalsa20_subkey(subkey, alice_pk, testNonce);

   /* Encrypt and MAC the plaintext */
   // memcpy(ciphertext + CRYPTO_BOX_AUTH_SIZE, plaintext, MSG_SIZE);
   // crypto_box(ciphertext + CRYPTO_BOX_AUTH_SIZE, /* message */
   //            MSG_SIZE,
   //            ciphertext, /* authenticator buffer */
   //            subkey,
   //            nonce + CRYPTO_BOX_XNONCE_SIZE);

}
