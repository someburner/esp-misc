#ifndef _TEST_CHACHA_POLY_H_
#define _TEST_CHACHA_POLY_H_

void TestChaChaPoly_init();
bool testDecrypt(uint8_t * input, uint16_t datalen);


#define MAX_PLAINTEXT_LEN 265


typedef struct {
   const char *name;
   uint8_t key[32];
   uint8_t plaintext[MAX_PLAINTEXT_LEN];
   uint8_t ciphertext[MAX_PLAINTEXT_LEN];
   uint8_t authdata[16];
   uint8_t iv[16];
   uint8_t tag[16];
   size_t authsize;
   size_t datasize;
   size_t tagsize;
   size_t ivsize;
} TestVector;



#endif /* end TestChaChaPoly.h */
