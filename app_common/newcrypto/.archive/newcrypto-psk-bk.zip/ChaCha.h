/*
 * Copyright (C) 2015 Southern Storm Software, Pty Ltd.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#ifndef CRYPTO_CHACHA_h
#define CRYPTO_CHACHA_h

// #include "Cipher.h"
#include "c_types.h"

#define NUM_ROUNDS_DEFAULT 20
#define POSN_DEFAULT 64

typedef struct
{
   uint8_t block[64];
   uint8_t stream[64];
   uint8_t rounds;
   uint8_t posn;
} ChaCha_Cipher_t;

// class ChaCha : public Cipher

size_t ChaCha_keySize();
size_t ChaCha_ivSize();

uint8_t ChaCha_numRounds();
void ChaCha_setNumRounds(uint8_t numRounds);

bool ChaCha_setKey( const uint8_t *key, size_t len);
bool ChaCha_setIV( const uint8_t *iv, size_t len);
bool ChaCha_setCounter( const uint8_t *counter, size_t len);

void ChaCha_encrypt(uint8_t *output, const uint8_t *input, size_t len);
void ChaCha_decrypt(uint8_t *output, const uint8_t *input, size_t len);

void ChaCha_clear();

void ChaCha_hashCore(uint32_t *output, const uint32_t *input, uint8_t rounds);

void ChaCha_keystreamBlock(uint32_t *output);

void ChaCha_init(uint8_t numRounds);

#endif
